h        h      a       sssss   l          ----------  Y      Y
h        h   a    a   s            l          -            Y    Y
hhhhhh  aaaaa   sssss   l          ----------      Y
h        h  a      a             s l          -               Y
h        h  a      a   sssss   lllllllll  -----------     Y

Made In C++

Created in jan 09 2024
by Hugopako

No, Not skidded
damage: Destructive
